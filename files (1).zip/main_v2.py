"""
╔══════════════════════════════════════════════════════════════╗
║   MediCore Hospital Management System v2.0                  ║
║   Features: Login • Reports • PDF Bills • Email Alerts      ║
╚══════════════════════════════════════════════════════════════╝
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sys, os, threading, tempfile

sys.path.insert(0, os.path.dirname(__file__))

from modules import database as db
from modules.database import initialize_database
from modules import auth
from modules.auth import initialize_users, login, can_access
from modules import email_module as em
from modules.email_module import initialize_email_settings

# ── Try importing optional heavy deps ──────────────────────────────────────
try:
    from modules import reports as rp
    HAS_MATPLOTLIB = True
except Exception:
    HAS_MATPLOTLIB = False

try:
    from modules.pdf_generator import generate_bill_pdf
    HAS_PDF = True
except Exception:
    HAS_PDF = False

# ══════════════════════════════════════════════════════════════
#  COLOURS
# ══════════════════════════════════════════════════════════════
C = {
    "bg":      "#0A0F1E",
    "bg2":     "#111827",
    "card":    "#1A2235",
    "input":   "#0D1526",
    "accent":  "#00D4FF",
    "a2":      "#7B61FF",
    "a3":      "#00FF9F",
    "a4":      "#FF6B6B",
    "a5":      "#FFB347",
    "fg":      "#FFFFFF",
    "fg2":     "#8B9EC7",
    "fg3":     "#C5D0E6",
    "border":  "#1E3050",
    "sidebar": "#080D1A",
    "ssel":    "#0D1E3D",
    "reven":   "#131D30",
    "rodd":    "#0F1825",
    "rsel":    "#1A3060",
}

NAV = [
    ("🏠","Dashboard",    "dashboard"),
    ("👥","Patients",     "patients"),
    ("👨‍⚕️","Doctors",     "doctors"),
    ("📅","Appointments", "appointments"),
    ("💰","Billing",      "billing"),
    ("💊","Inventory",    "inventory"),
    ("👷","Staff",        "staff"),
    ("📊","Reports",      "reports"),
    ("👤","Users",        "users"),
    ("⚙️","Settings",     "settings"),
]

# ══════════════════════════════════════════════════════════════
#  REUSABLE WIDGETS
# ══════════════════════════════════════════════════════════════
class Btn(tk.Button):
    STYLES = {
        "primary": C["accent"],
        "success": C["a3"],
        "danger":  C["a4"],
        "warning": C["a5"],
        "purple":  C["a2"],
    }
    def __init__(self, master, text, command=None, style="primary", **kw):
        bg = self.STYLES.get(style, C["accent"])
        super().__init__(master, text=text, command=command,
                         bg=bg, fg=C["bg"], font=("Consolas",9,"bold"),
                         relief="flat", cursor="hand2", padx=12, pady=7,
                         activebackground=C["card"], activeforeground=bg, **kw)

class Ent(tk.Entry):
    def __init__(self, master, ph="", **kw):
        super().__init__(master, bg=C["input"], fg=C["fg"],
                         insertbackground=C["accent"], relief="flat",
                         font=("Consolas",10), bd=0,
                         highlightthickness=1, highlightcolor=C["accent"],
                         highlightbackground=C["border"], **kw)
        self._ph = ph; self._focused = False
        if ph:
            self._put_ph()
            self.bind("<FocusIn>",  self._fi)
            self.bind("<FocusOut>", self._fo)
    def _put_ph(self): self.insert(0,self._ph); self.config(fg=C["fg2"])
    def _fi(self,_):
        if not self._focused and self.get()==self._ph:
            self.delete(0,"end"); self.config(fg=C["fg"])
        self._focused=True
    def _fo(self,_):
        if not self.get(): self._focused=False; self._put_ph()
    def val(self):
        v=self.get(); return "" if v==self._ph else v

class Combo(ttk.Combobox):
    def __init__(self, master, **kw):
        super().__init__(master, font=("Consolas",10), **kw)

def treeview(parent, cols, h=16):
    style=ttk.Style(); style.theme_use("clam")
    style.configure("H.Treeview", background=C["rodd"], foreground=C["fg"],
                    fieldbackground=C["rodd"], rowheight=30, font=("Consolas",9))
    style.configure("H.Treeview.Heading", background=C["card"],
                    foreground=C["accent"], font=("Consolas",9,"bold"), relief="flat")
    style.map("H.Treeview", background=[("selected",C["rsel"])],
              foreground=[("selected",C["accent"])])
    f=tk.Frame(parent,bg=C["bg2"]); f.pack(fill="both",expand=True)
    sy=tk.Scrollbar(f,orient="vertical"); sy.pack(side="right",fill="y")
    sx=tk.Scrollbar(f,orient="horizontal"); sx.pack(side="bottom",fill="x")
    tv=ttk.Treeview(f,columns=cols,show="headings",style="H.Treeview",
                    height=h,yscrollcommand=sy.set,xscrollcommand=sx.set)
    sy.config(command=tv.yview); sx.config(command=tv.xview)
    tv.pack(fill="both",expand=True)
    for c in cols:
        tv.heading(c,text=c); tv.column(c,width=120,anchor="center")
    tv.tag_configure("e",background=C["reven"])
    tv.tag_configure("o",background=C["rodd"])
    return tv

def card_frame(master, title=""):
    f=tk.LabelFrame(master, text=f"  {title}  ",
                    bg=C["card"], fg=C["accent"],
                    font=("Consolas",10,"bold"), bd=1,
                    highlightbackground=C["border"], padx=10, pady=8)
    return f

def stat_card(master, icon, value, label, color):
    f=tk.Frame(master, bg=C["card"], padx=16, pady=12,
               highlightthickness=1, highlightbackground=color)
    tk.Label(f,text=icon, bg=C["card"], fg=color, font=("Segoe UI Emoji",24)).pack(anchor="w")
    tk.Label(f,text=str(value), bg=C["card"], fg=color,
             font=("Consolas",24,"bold")).pack(anchor="w")
    tk.Label(f,text=label, bg=C["card"], fg=C["fg2"],
             font=("Consolas",9)).pack(anchor="w")
    return f

# ══════════════════════════════════════════════════════════════
#  LOGIN WINDOW
# ══════════════════════════════════════════════════════════════
class LoginWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        initialize_database()
        initialize_users()
        initialize_email_settings()
        self.title("MediCore — Login")
        self.geometry("440x500")
        self.resizable(False,False)
        self.configure(bg=C["bg"])
        self.user = None
        self._build()
        self.bind("<Return>", lambda _: self._login())

    def _build(self):
        tk.Label(self, text="🏥", bg=C["bg"], fg=C["accent"],
                 font=("Segoe UI Emoji",48)).pack(pady=(40,4))
        tk.Label(self, text="MediCore", bg=C["bg"], fg=C["accent"],
                 font=("Consolas",22,"bold")).pack()
        tk.Label(self, text="Hospital Management System", bg=C["bg"],
                 fg=C["fg2"], font=("Consolas",10)).pack(pady=(0,30))

        box = tk.Frame(self, bg=C["card"], padx=30, pady=28,
                       highlightthickness=1, highlightbackground=C["border"])
        box.pack(padx=40, fill="x")

        tk.Label(box, text="Username", bg=C["card"], fg=C["fg2"],
                 font=("Consolas",9)).pack(anchor="w")
        self._user_e = Ent(box, ph="Enter username", width=30)
        self._user_e.pack(fill="x", ipady=7, pady=(2,12))

        tk.Label(box, text="Password", bg=C["card"], fg=C["fg2"],
                 font=("Consolas",9)).pack(anchor="w")
        self._pass_e = Ent(box, ph="Enter password", show="*", width=30)
        self._pass_e.pack(fill="x", ipady=7, pady=(2,16))

        Btn(box, "🔐  LOGIN", self._login, "success").pack(fill="x", ipady=4)
        self._err = tk.Label(box, text="", bg=C["card"], fg=C["a4"],
                             font=("Consolas",9))
        self._err.pack(pady=(10,0))

        # Default credentials hint
        hint = tk.Frame(self, bg=C["bg"])
        hint.pack(pady=20)
        tk.Label(hint, text="Default accounts:", bg=C["bg"], fg=C["fg2"],
                 font=("Consolas",9,"bold")).pack()
        for u,p,r in [("admin","admin123","Admin"),
                       ("doctor1","doc123","Doctor"),
                       ("receptionist","rec123","Receptionist")]:
            tk.Label(hint, text=f"{u} / {p}  [{r}]", bg=C["bg"],
                     fg=C["fg3"], font=("Consolas",9)).pack()

    def _login(self):
        u = self._user_e.val() or self._user_e.get()
        p = self._pass_e.val() or self._pass_e.get()
        if u in ("Enter username","") or p in ("Enter password",""):
            self._err.config(text="Please enter credentials!"); return
        result = login(u, p)
        if result:
            self.user = result
            self.destroy()
        else:
            self._err.config(text="❌  Invalid username or password!")

# ══════════════════════════════════════════════════════════════
#  MAIN APP
# ══════════════════════════════════════════════════════════════
class HospitalApp(tk.Tk):
    def __init__(self, user: dict):
        super().__init__()
        self.user = user
        self.title(f"🏥 MediCore — {user['full_name']}  [{user['role'].upper()}]")
        self.geometry("1350x800")
        self.minsize(1100,680)
        self.configure(bg=C["bg"])
        self._current = None
        self._build()
        self._show("dashboard")

    def _build(self):
        # Top bar
        top = tk.Frame(self, bg=C["bg2"], height=50)
        top.pack(fill="x"); top.pack_propagate(False)
        tk.Label(top, text="🏥  MediCore v2.0", bg=C["bg2"], fg=C["accent"],
                 font=("Consolas",14,"bold")).pack(side="left",padx=20,pady=12)
        tk.Label(top, text=f"👤 {self.user['full_name']}  |  {self.user['role'].upper()}",
                 bg=C["bg2"], fg=C["fg2"], font=("Consolas",9)).pack(side="right",padx=60)
        Btn(top, "🚪 Logout", self._logout, "danger").pack(side="right",padx=6,pady=8)

        body = tk.Frame(self, bg=C["bg"]); body.pack(fill="both",expand=True)

        # Sidebar
        self._sidebar = tk.Frame(body, bg=C["sidebar"], width=195)
        self._sidebar.pack(side="left",fill="y"); self._sidebar.pack_propagate(False)
        tk.Label(self._sidebar, text="NAVIGATION", bg=C["sidebar"], fg=C["fg2"],
                 font=("Consolas",8,"bold")).pack(pady=(18,6),padx=14,anchor="w")

        self._nav_btns = {}
        for icon,label,key in NAV:
            if not can_access(self.user["role"], key):
                continue
            btn = tk.Label(self._sidebar, text=f"  {icon}  {label}",
                           bg=C["sidebar"], fg=C["fg3"],
                           font=("Consolas",11), anchor="w",
                           padx=8, pady=11, cursor="hand2")
            btn.pack(fill="x")
            btn.bind("<Button-1>", lambda e,k=key: self._show(k))
            btn.bind("<Enter>",    lambda e,b=btn: b.config(bg=C["ssel"],fg=C["accent"]))
            btn.bind("<Leave>",    lambda e,b=btn,k=key:
                     b.config(bg=C["ssel"] if self._current==k else C["sidebar"],
                              fg=C["accent"] if self._current==k else C["fg3"]))
            self._nav_btns[key] = btn

        self._content = tk.Frame(body, bg=C["bg"])
        self._content.pack(side="left",fill="both",expand=True)

    def _show(self, key):
        if not can_access(self.user["role"], key):
            messagebox.showwarning("Access Denied", f"Your role cannot access '{key}'.")
            return
        if self._current == key: return
        self._current = key
        for k,b in self._nav_btns.items():
            b.config(bg=C["ssel"] if k==key else C["sidebar"],
                     fg=C["accent"] if k==key else C["fg3"])
        for w in self._content.winfo_children(): w.destroy()

        pages = {
            "dashboard":    DashboardPage,
            "patients":     PatientsPage,
            "doctors":      DoctorsPage,
            "appointments": AppointmentsPage,
            "billing":      BillingPage,
            "inventory":    InventoryPage,
            "staff":        StaffPage,
            "reports":      ReportsPage,
            "users":        UsersPage,
            "settings":     SettingsPage,
        }
        if key in pages:
            pages[key](self._content, self.user)

    def _logout(self):
        self.destroy()
        lw = LoginWindow()
        lw.mainloop()
        if lw.user:
            HospitalApp(lw.user).mainloop()

# ══════════════════════════════════════════════════════════════
#  PAGE BASE
# ══════════════════════════════════════════════════════════════
class BasePage(tk.Frame):
    def __init__(self, master, user, title=""):
        super().__init__(master, bg=C["bg"])
        self.pack(fill="both", expand=True, padx=22, pady=18)
        self.user = user
        if title:
            tk.Label(self, text=title, bg=C["bg"], fg=C["accent"],
                     font=("Consolas",15,"bold")).pack(anchor="w",pady=(0,14))

# ══════════════════════════════════════════════════════════════
#  DASHBOARD
# ══════════════════════════════════════════════════════════════
class DashboardPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "📊  DASHBOARD OVERVIEW")
        stats = db.get_dashboard_stats()
        cards = [
            ("👥","Total Patients",      stats["total_patients"],     C["accent"]),
            ("👨‍⚕️","Total Doctors",      stats["total_doctors"],      C["a2"]),
            ("📅","Today Appointments",  stats["today_appointments"], C["a3"]),
            ("🗓️","Total Appointments",  stats["total_appointments"], C["a5"]),
            ("💰",f"Revenue Rs.",        f"{stats['total_revenue']:.0f}", C["a3"]),
            ("⚠️","Pending Bills",       stats["pending_bills"],      C["a4"]),
            ("💊","Low Stock Items",     stats["low_stock_items"],    C["a5"]),
            ("👷","Total Staff",         stats["total_staff"],        C["a2"]),
        ]
        g = tk.Frame(self, bg=C["bg"]); g.pack(fill="x")
        for i,(icon,lbl,val,col) in enumerate(cards):
            c = stat_card(g,icon,val,lbl,col)
            c.grid(row=i//4, column=i%4, padx=8,pady=8,sticky="nsew")
            g.columnconfigure(i%4, weight=1)

        tk.Label(self, text="📋  RECENT APPOINTMENTS", bg=C["bg"], fg=C["accent"],
                 font=("Consolas",12,"bold")).pack(anchor="w",pady=(18,6))
        cols=["ID","Patient","Doctor","Specialization","Date","Time","Status"]
        tv=treeview(self,cols,h=8)
        for i,r in enumerate(db.get_all_appointments()[:10]):
            tv.insert("","end",values=(
                r["appointment_id"],r["patient"],r["doctor"],
                r["specialization"],r["appointment_date"],
                r["appointment_time"],r["status"],
            ), tags=("e" if i%2==0 else "o",))

# ══════════════════════════════════════════════════════════════
#  PATIENTS
# ══════════════════════════════════════════════════════════════
class PatientsPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "👥  PATIENT RECORDS")
        self._sid = None
        sf=tk.Frame(self,bg=C["bg"]); sf.pack(fill="x",pady=(0,8))
        self._sv=tk.StringVar()
        Ent(sf,ph="Search name/phone/ID…",textvariable=self._sv,width=38).pack(side="left",ipady=6,padx=(0,6))
        Btn(sf,"🔍 Search",self._search).pack(side="left",padx=3)
        Btn(sf,"🔄 Refresh",self._load,"purple").pack(side="left",padx=3)

        fc=card_frame(self,"➕ Add / Edit Patient"); fc.pack(fill="x",pady=(0,10))
        flds=[("Name",None),("Age",None),("Gender",["Male","Female","Other"]),
              ("Blood Group",["A+","A-","B+","B-","AB+","AB-","O+","O-"]),
              ("Phone",None),("Email",None),("Address",None),("Medical History",None)]
        self._e={}
        for i,(lbl,opts) in enumerate(flds):
            r,c=divmod(i,4)
            tk.Label(fc,text=lbl,bg=C["card"],fg=C["fg2"],
                     font=("Consolas",9)).grid(row=r*2,column=c,sticky="w",padx=6,pady=(4,0))
            w=Combo(fc,values=opts,width=17) if opts else Ent(fc,width=18)
            w.grid(row=r*2+1,column=c,padx=6,pady=(2,6),ipady=5,sticky="ew")
            fc.columnconfigure(c,weight=1); self._e[lbl]=w

        bf=tk.Frame(fc,bg=C["card"]); bf.grid(row=6,column=0,columnspan=4,pady=6)
        Btn(bf,"💾 Save",    self._save,   "success").pack(side="left",padx=5)
        Btn(bf,"✏️ Update",  self._update, "warning").pack(side="left",padx=5)
        Btn(bf,"🗑️ Delete",  self._delete, "danger").pack(side="left",padx=5)
        Btn(bf,"🧹 Clear",   self._clear,  "purple").pack(side="left",padx=5)

        cols=["ID","Name","Age","Gender","Blood","Phone","Email","Address","History","Added"]
        self._tv=treeview(self,cols)
        self._tv.bind("<<TreeviewSelect>>",self._sel)
        self._load()

    def _load(self):
        self._tv.delete(*self._tv.get_children())
        for i,r in enumerate(db.get_all_patients()):
            self._tv.insert("","end",values=(
                r["patient_id"],r["name"],r["age"],r["gender"],
                r["blood_group"],r["phone"],r["email"],
                r["address"],r["medical_history"],r["created_at"][:10],
            ),tags=("e" if i%2==0 else "o",))

    def _search(self):
        kw=self._sv.get().strip()
        if not kw: self._load(); return
        self._tv.delete(*self._tv.get_children())
        for i,r in enumerate(db.search_patients(kw)):
            self._tv.insert("","end",values=(
                r["patient_id"],r["name"],r["age"],r["gender"],
                r["blood_group"],r["phone"],r["email"],
                r["address"],r["medical_history"],r["created_at"][:10],
            ),tags=("e" if i%2==0 else "o",))

    def _gv(self):
        out={}
        for k,w in self._e.items():
            out[k]=w.get() if isinstance(w,Combo) else w.val()
        return out

    def _save(self):
        v=self._gv()
        if not v["Name"]: messagebox.showerror("Error","Name required!"); return
        db.add_patient(v["Name"],v["Age"] or 0,v["Gender"],v["Blood Group"],
                       v["Phone"],v["Email"],v["Address"],v["Medical History"])
        messagebox.showinfo("✅","Patient added!"); self._clear(); self._load()

    def _update(self):
        if not self._sid: messagebox.showwarning("⚠️","Select a patient!"); return
        v=self._gv()
        db.update_patient(self._sid,v["Name"],v["Age"] or 0,v["Gender"],
                          v["Blood Group"],v["Phone"],v["Email"],
                          v["Address"],v["Medical History"])
        messagebox.showinfo("✅","Updated!"); self._clear(); self._load()

    def _delete(self):
        if not self._sid: messagebox.showwarning("⚠️","Select a patient!"); return
        if messagebox.askyesno("Confirm","Delete patient?"):
            db.delete_patient(self._sid); self._clear(); self._load()

    def _sel(self,_):
        sel=self._tv.selection()
        if not sel: return
        vals=self._tv.item(sel[0])["values"]; self._sid=vals[0]
        keys=["Name","Age","Gender","Blood Group","Phone","Email","Address","Medical History"]
        for i,k in enumerate(keys):
            w=self._e[k]; v=str(vals[i+1]) if vals[i+1] else ""
            if isinstance(w,Combo): w.set(v)
            else:
                w.delete(0,"end"); w.insert(0,v); w.config(fg=C["fg"])

    def _clear(self):
        self._sid=None
        for w in self._e.values():
            if isinstance(w,Combo): w.set("")
            else: w.delete(0,"end")

# ══════════════════════════════════════════════════════════════
#  DOCTORS
# ══════════════════════════════════════════════════════════════
class DoctorsPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "👨‍⚕️  DOCTOR MANAGEMENT")
        self._sid=None
        sf=tk.Frame(self,bg=C["bg"]); sf.pack(fill="x",pady=(0,8))
        self._sv=tk.StringVar()
        Ent(sf,ph="Search name/specialization…",textvariable=self._sv,width=38).pack(side="left",ipady=6,padx=(0,6))
        Btn(sf,"🔍 Search",self._search).pack(side="left",padx=3)
        Btn(sf,"🔄 Refresh",self._load,"purple").pack(side="left",padx=3)

        specs=["Cardiology","Neurology","Orthopedics","Pediatrics","Dermatology",
               "Gynecology","General Medicine","Ophthalmology","Dentistry","Psychiatry"]
        fc=card_frame(self,"➕ Add / Edit Doctor"); fc.pack(fill="x",pady=(0,10))
        flds=[("Name",None),("Specialization",specs),("Phone",None),
              ("Email",None),("Experience",None),("Fee Rs.",None)]
        self._e={}
        for i,(lbl,opts) in enumerate(flds):
            r,c=divmod(i,3)
            tk.Label(fc,text=lbl,bg=C["card"],fg=C["fg2"],
                     font=("Consolas",9)).grid(row=r*2,column=c,sticky="w",padx=6,pady=(4,0))
            w=Combo(fc,values=opts,width=20) if opts else Ent(fc,width=22)
            w.grid(row=r*2+1,column=c,padx=6,pady=(2,6),ipady=5,sticky="ew")
            fc.columnconfigure(c,weight=1); self._e[lbl]=w

        self._av=tk.IntVar(value=1)
        tk.Checkbutton(fc,text="Available",variable=self._av,
                       bg=C["card"],fg=C["a3"],activebackground=C["card"],
                       selectcolor=C["bg"],font=("Consolas",10)
                       ).grid(row=5,column=0,sticky="w",padx=6)

        bf=tk.Frame(fc,bg=C["card"]); bf.grid(row=5,column=1,columnspan=2,pady=6)
        Btn(bf,"💾 Save",   self._save,   "success").pack(side="left",padx=5)
        Btn(bf,"✏️ Update", self._update, "warning").pack(side="left",padx=5)
        Btn(bf,"🗑️ Delete", self._delete, "danger").pack(side="left",padx=5)
        Btn(bf,"🧹 Clear",  self._clear,  "purple").pack(side="left",padx=5)

        cols=["ID","Name","Specialization","Phone","Email","Exp","Fee Rs.","Available","Added"]
        self._tv=treeview(self,cols)
        self._tv.bind("<<TreeviewSelect>>",self._sel)
        self._load()

    def _load(self):
        self._tv.delete(*self._tv.get_children())
        for i,r in enumerate(db.get_all_doctors()):
            self._tv.insert("","end",values=(
                r["doctor_id"],r["name"],r["specialization"],r["phone"],
                r["email"],r["experience"],f"Rs.{r['fee']:.0f}",
                "Yes" if r["available"] else "No",r["created_at"][:10],
            ),tags=("e" if i%2==0 else "o",))

    def _search(self):
        kw=self._sv.get().strip()
        if not kw: self._load(); return
        self._tv.delete(*self._tv.get_children())
        for i,r in enumerate(db.search_doctors(kw)):
            self._tv.insert("","end",values=(
                r["doctor_id"],r["name"],r["specialization"],r["phone"],
                r["email"],r["experience"],f"Rs.{r['fee']:.0f}",
                "Yes" if r["available"] else "No",r["created_at"][:10],
            ),tags=("e" if i%2==0 else "o",))

    def _gv(self):
        out={}
        for k,w in self._e.items():
            out[k]=w.get() if isinstance(w,Combo) else w.val()
        return out

    def _save(self):
        v=self._gv()
        if not v["Name"]: messagebox.showerror("Error","Name required!"); return
        db.add_doctor(v["Name"],v["Specialization"],v["Phone"],v["Email"],
                      v["Experience"] or 0,v["Fee Rs."] or 0)
        messagebox.showinfo("✅","Doctor added!"); self._clear(); self._load()

    def _update(self):
        if not self._sid: messagebox.showwarning("⚠️","Select!"); return
        v=self._gv()
        db.update_doctor(self._sid,v["Name"],v["Specialization"],v["Phone"],
                         v["Email"],v["Experience"] or 0,v["Fee Rs."] or 0,self._av.get())
        messagebox.showinfo("✅","Updated!"); self._clear(); self._load()

    def _delete(self):
        if not self._sid: messagebox.showwarning("⚠️","Select!"); return
        if messagebox.askyesno("Confirm","Delete doctor?"):
            db.delete_doctor(self._sid); self._clear(); self._load()

    def _sel(self,_):
        sel=self._tv.selection()
        if not sel: return
        vals=self._tv.item(sel[0])["values"]; self._sid=vals[0]
        keys=["Name","Specialization","Phone","Email","Experience","Fee Rs."]
        for i,k in enumerate(keys):
            w=self._e[k]; v=str(vals[i+1]).replace("Rs.","")
            if isinstance(w,Combo): w.set(v)
            else:
                w.delete(0,"end"); w.insert(0,v); w.config(fg=C["fg"])
        self._av.set(1 if vals[7]=="Yes" else 0)

    def _clear(self):
        self._sid=None
        for w in self._e.values():
            if isinstance(w,Combo): w.set("")
            else: w.delete(0,"end")
        self._av.set(1)

# ══════════════════════════════════════════════════════════════
#  APPOINTMENTS
# ══════════════════════════════════════════════════════════════
class AppointmentsPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "📅  APPOINTMENT BOOKING")
        self._sid=None
        patients=db.get_all_patients()
        doctors=db.get_all_doctors()
        p_opts=[f"{r['patient_id']} – {r['name']}" for r in patients]
        d_opts=[f"{r['doctor_id']} – {r['name']} ({r['specialization']})" for r in doctors]

        fc=card_frame(self,"🗓️ Book Appointment"); fc.pack(fill="x",pady=(0,10))
        flds=[("Select Patient",p_opts),("Select Doctor",d_opts),
              ("Date (YYYY-MM-DD)",None),("Time (HH:MM)",None),("Reason",None)]
        self._e={}
        for i,(lbl,opts) in enumerate(flds):
            r,c=divmod(i,3)
            tk.Label(fc,text=lbl,bg=C["card"],fg=C["fg2"],
                     font=("Consolas",9)).grid(row=r*2,column=c,sticky="w",padx=6,pady=(4,0))
            w=Combo(fc,values=opts,width=30) if opts else Ent(fc,width=22)
            w.grid(row=r*2+1,column=c,padx=6,pady=(2,6),ipady=5,sticky="ew")
            fc.columnconfigure(c,weight=1); self._e[lbl]=w

        bf=tk.Frame(fc,bg=C["card"]); bf.grid(row=6,column=0,columnspan=3,pady=6)
        Btn(bf,"📅 Book",        self._book,     "success").pack(side="left",padx=5)
        Btn(bf,"✅ Complete",    self._complete, "primary").pack(side="left",padx=5)
        Btn(bf,"❌ Cancel",      self._cancel,   "danger").pack(side="left",padx=5)
        Btn(bf,"🗑️ Delete",      self._delete,   "warning").pack(side="left",padx=5)
        Btn(bf,"📧 Email Confirm",self._email_confirm,"purple").pack(side="left",padx=5)
        Btn(bf,"🔄 Refresh",     self._load,     "purple").pack(side="left",padx=5)

        cols=["ID","Patient","Doctor","Spec","Date","Time","Reason","Status","Notes"]
        self._tv=treeview(self,cols)
        self._tv.bind("<<TreeviewSelect>>",self._sel)
        self._load()

    def _load(self):
        self._tv.delete(*self._tv.get_children())
        for i,r in enumerate(db.get_all_appointments()):
            self._tv.insert("","end",values=(
                r["appointment_id"],r["patient"],r["doctor"],r["specialization"],
                r["appointment_date"],r["appointment_time"],r["reason"],
                r["status"],r["notes"] or "",
            ),tags=("e" if i%2==0 else "o",))

    def _book(self):
        p=self._e["Select Patient"].get()
        d=self._e["Select Doctor"].get()
        date=self._e["Date (YYYY-MM-DD)"].val()
        time=self._e["Time (HH:MM)"].val()
        reason=self._e["Reason"].val()
        if not (p and d and date and time):
            messagebox.showerror("Error","Patient, Doctor, Date, Time required!"); return
        pid=int(p.split("–")[0].strip())
        did=int(d.split("–")[0].strip())
        db.add_appointment(pid,did,date,time,reason)
        messagebox.showinfo("✅","Appointment booked!"); self._load()

    def _sel(self,_):
        sel=self._tv.selection()
        if sel: self._sid=self._tv.item(sel[0])["values"][0]

    def _complete(self):
        if not self._sid: messagebox.showwarning("⚠️","Select!"); return
        db.update_appointment_status(self._sid,"Completed"); self._load()

    def _cancel(self):
        if not self._sid: messagebox.showwarning("⚠️","Select!"); return
        db.update_appointment_status(self._sid,"Cancelled"); self._load()

    def _delete(self):
        if not self._sid: messagebox.showwarning("⚠️","Select!"); return
        if messagebox.askyesno("Confirm","Delete appointment?"):
            db.delete_appointment(self._sid); self._sid=None; self._load()

    def _email_confirm(self):
        if not self._sid: messagebox.showwarning("⚠️","Select appointment!"); return
        sel=self._tv.selection()
        if not sel: return
        vals=self._tv.item(sel[0])["values"]
        conn=db.get_connection()
        # Get patient email
        pt=conn.execute(
            "SELECT email,name FROM patients p JOIN appointments a ON p.patient_id=a.patient_id WHERE a.appointment_id=?",
            (self._sid,),
        ).fetchone()
        conn.close()
        if not pt or not pt["email"]:
            messagebox.showwarning("⚠️","Patient email not found!"); return
        ok,msg=em.send_appointment_confirmation(
            pt["email"],pt["name"],vals[2],vals[4],vals[5],vals[6])
        (messagebox.showinfo if ok else messagebox.showerror)("Email",msg)

# ══════════════════════════════════════════════════════════════
#  BILLING (with PDF + Email)
# ══════════════════════════════════════════════════════════════
class BillingPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "💰  BILLING & PAYMENTS")
        self._sid=None
        patients=db.get_all_patients()
        apts=db.get_all_appointments()
        p_opts=[f"{r['patient_id']} – {r['name']}" for r in patients]
        a_opts=[f"{r['appointment_id']} – {r['patient']} ({r['appointment_date']})" for r in apts]

        fc=card_frame(self,"🧾 Generate Bill"); fc.pack(fill="x",pady=(0,10))
        flds=[("Select Patient",p_opts),("Appointment (opt.)",a_opts),
              ("Total Amount Rs.",None),("Amount Paid Rs.",None),("Description",None)]
        self._e={}
        for i,(lbl,opts) in enumerate(flds):
            r,c=divmod(i,3)
            tk.Label(fc,text=lbl,bg=C["card"],fg=C["fg2"],
                     font=("Consolas",9)).grid(row=r*2,column=c,sticky="w",padx=6,pady=(4,0))
            w=Combo(fc,values=opts,width=30) if opts else Ent(fc,width=22)
            w.grid(row=r*2+1,column=c,padx=6,pady=(2,6),ipady=5,sticky="ew")
            fc.columnconfigure(c,weight=1); self._e[lbl]=w

        bf=tk.Frame(fc,bg=C["card"]); bf.grid(row=6,column=0,columnspan=3,pady=6)
        Btn(bf,"🧾 Generate Bill",  self._generate, "success").pack(side="left",padx=5)
        Btn(bf,"🖨️ Download PDF",   self._pdf,      "primary").pack(side="left",padx=5)
        Btn(bf,"📧 Email Bill",     self._email,    "purple").pack(side="left",padx=5)
        Btn(bf,"🔄 Refresh",        self._load,     "warning").pack(side="left",padx=5)

        cols=["Bill ID","Patient","Amount Rs.","Paid Rs.","Status","Date","Description"]
        self._tv=treeview(self,cols)
        self._tv.bind("<<TreeviewSelect>>",self._sel)
        self._load()

    def _load(self):
        self._tv.delete(*self._tv.get_children())
        for i,r in enumerate(db.get_all_bills()):
            self._tv.insert("","end",values=(
                r["bill_id"],r["patient"],f"Rs.{r['amount']:.2f}",
                f"Rs.{r['paid']:.2f}",r["payment_status"],
                r["bill_date"][:10],r["description"] or "",
            ),tags=("e" if i%2==0 else "o",))

    def _generate(self):
        p=self._e["Select Patient"].get()
        if not p: messagebox.showerror("Error","Select patient!"); return
        pid=int(p.split("–")[0].strip())
        a=self._e["Appointment (opt.)"].get()
        aid=int(a.split("–")[0].strip()) if a else None
        try:
            amount=float(self._e["Total Amount Rs."].val() or 0)
            paid  =float(self._e["Amount Paid Rs."].val() or 0)
        except ValueError:
            messagebox.showerror("Error","Enter valid amounts!"); return
        desc=self._e["Description"].val()
        db.add_bill(pid,aid,amount,paid,desc)
        messagebox.showinfo("✅","Bill generated!"); self._load()

    def _sel(self,_):
        sel=self._tv.selection()
        if sel: self._sid=self._tv.item(sel[0])["values"][0]

    def _get_bill_data(self):
        if not self._sid: messagebox.showwarning("⚠️","Select a bill!"); return None
        sel=self._tv.selection()
        if not sel: return None
        vals=self._tv.item(sel[0])["values"]
        conn=db.get_connection()
        pt=conn.execute(
            "SELECT p.name,p.phone,p.address,p.email FROM billing b "
            "JOIN patients p ON b.patient_id=p.patient_id WHERE b.bill_id=?",
            (self._sid,),
        ).fetchone()
        conn.close()
        amount=float(str(vals[2]).replace("Rs.",""))
        paid  =float(str(vals[3]).replace("Rs.",""))
        return {
            "bill_id":        self._sid,
            "patient_name":   pt["name"] if pt else "—",
            "patient_phone":  pt["phone"] if pt else "—",
            "patient_address":pt["address"] if pt else "—",
            "patient_email":  pt["email"] if pt else "",
            "doctor_name":    "—",
            "appointment_date":"—",
            "total":          amount,
            "paid":           paid,
            "tax":            0,
            "payment_status": vals[4],
            "description":    vals[6],
        }

    def _pdf(self):
        if not HAS_PDF:
            messagebox.showerror("Error","reportlab not installed!"); return
        data=self._get_bill_data()
        if not data: return
        path=filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF Files","*.pdf")],
            initialfile=f"Bill_{self._sid}.pdf",
        )
        if not path: return
        try:
            generate_bill_pdf(data, path)
            messagebox.showinfo("✅",f"PDF saved:\n{path}")
        except Exception as ex:
            messagebox.showerror("Error",str(ex))

    def _email(self):
        data=self._get_bill_data()
        if not data: return
        email=data.get("patient_email","")
        if not email:
            messagebox.showwarning("⚠️","Patient email not set!"); return
        # Generate temp PDF if available
        pdf_path=None
        if HAS_PDF:
            tmp=os.path.join(tempfile.gettempdir(),f"bill_{self._sid}.pdf")
            try: generate_bill_pdf(data,tmp); pdf_path=tmp
            except: pass
        ok,msg=em.send_bill_email(
            email, data["patient_name"], self._sid,
            data["total"], data["paid"], data["payment_status"], pdf_path,
        )
        (messagebox.showinfo if ok else messagebox.showerror)("Email",msg)

# ══════════════════════════════════════════════════════════════
#  INVENTORY
# ══════════════════════════════════════════════════════════════
class InventoryPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "💊  MEDICINE & INVENTORY")
        self._sid=None
        cats=["Medicine","Equipment","Consumable","Surgical","Diagnostic"]
        fc=card_frame(self,"➕ Add / Edit Item"); fc.pack(fill="x",pady=(0,10))
        flds=[("Item Name",None),("Category",cats),("Quantity",None),
              ("Unit Price Rs.",None),("Supplier",None),("Expiry Date",None)]
        self._e={}
        for i,(lbl,opts) in enumerate(flds):
            r,c=divmod(i,3)
            tk.Label(fc,text=lbl,bg=C["card"],fg=C["fg2"],
                     font=("Consolas",9)).grid(row=r*2,column=c,sticky="w",padx=6,pady=(4,0))
            w=Combo(fc,values=opts,width=20) if opts else Ent(fc,width=20)
            w.grid(row=r*2+1,column=c,padx=6,pady=(2,6),ipady=5,sticky="ew")
            fc.columnconfigure(c,weight=1); self._e[lbl]=w

        bf=tk.Frame(fc,bg=C["card"]); bf.grid(row=6,column=0,columnspan=3,pady=6)
        Btn(bf,"💾 Add",     self._save,   "success").pack(side="left",padx=5)
        Btn(bf,"✏️ Update",  self._update, "warning").pack(side="left",padx=5)
        Btn(bf,"🗑️ Delete",  self._delete, "danger").pack(side="left",padx=5)
        Btn(bf,"🧹 Clear",   self._clear,  "purple").pack(side="left",padx=5)
        Btn(bf,"📧 Low Stock Alert", self._low_stock_email,"primary").pack(side="left",padx=5)
        Btn(bf,"🔄 Refresh", self._load,   "purple").pack(side="left",padx=5)

        cols=["ID","Item Name","Category","Quantity","Unit Price","Supplier","Expiry","Added"]
        self._tv=treeview(self,cols)
        self._tv.bind("<<TreeviewSelect>>",self._sel)
        self._load()

    def _load(self):
        self._tv.delete(*self._tv.get_children())
        for i,r in enumerate(db.get_all_inventory()):
            self._tv.insert("","end",values=(
                r["item_id"],r["item_name"],r["category"],r["quantity"],
                f"Rs.{r['unit_price']:.2f}",r["supplier"],
                r["expiry_date"],r["created_at"][:10],
            ),tags=("e" if i%2==0 else "o",))

    def _gv(self):
        out={}
        for k,w in self._e.items():
            out[k]=w.get() if isinstance(w,Combo) else w.val()
        return out

    def _save(self):
        v=self._gv()
        if not v["Item Name"]: messagebox.showerror("Error","Name required!"); return
        db.add_inventory_item(v["Item Name"],v["Category"],
                              int(v["Quantity"] or 0),float(v["Unit Price Rs."] or 0),
                              v["Supplier"],v["Expiry Date"])
        messagebox.showinfo("✅","Added!"); self._clear(); self._load()

    def _update(self):
        if not self._sid: messagebox.showwarning("⚠️","Select!"); return
        v=self._gv()
        db.update_inventory(self._sid,v["Item Name"],v["Category"],
                            int(v["Quantity"] or 0),float(v["Unit Price Rs."] or 0),
                            v["Supplier"],v["Expiry Date"])
        messagebox.showinfo("✅","Updated!"); self._clear(); self._load()

    def _delete(self):
        if not self._sid: messagebox.showwarning("⚠️","Select!"); return
        if messagebox.askyesno("Confirm","Delete?"):
            db.delete_inventory_item(self._sid); self._clear(); self._load()

    def _sel(self,_):
        sel=self._tv.selection()
        if not sel: return
        vals=self._tv.item(sel[0])["values"]; self._sid=vals[0]
        keys=["Item Name","Category","Quantity","Unit Price Rs.","Supplier","Expiry Date"]
        for i,k in enumerate(keys):
            w=self._e[k]; v=str(vals[i+1]).replace("Rs.","")
            if isinstance(w,Combo): w.set(v)
            else:
                w.delete(0,"end"); w.insert(0,v); w.config(fg=C["fg"])

    def _clear(self):
        self._sid=None
        for w in self._e.values():
            if isinstance(w,Combo): w.set("")
            else: w.delete(0,"end")

    def _low_stock_email(self):
        items=[]
        for r in db.get_all_inventory():
            if r["quantity"] < 50:
                items.append({"name":r["item_name"],"qty":r["quantity"],"category":r["category"]})
        if not items: messagebox.showinfo("✅","All items are well stocked!"); return
        cfg=em.get_email_settings()
        admin_email=cfg.get("sender_email","")
        if not admin_email:
            messagebox.showwarning("⚠️","Configure email in Settings first!"); return
        ok,msg=em.send_low_stock_alert(admin_email,items)
        (messagebox.showinfo if ok else messagebox.showerror)("Email",msg)

# ══════════════════════════════════════════════════════════════
#  STAFF
# ══════════════════════════════════════════════════════════════
class StaffPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "👷  STAFF MANAGEMENT")
        self._sid=None
        roles=["Nurse","Receptionist","Pharmacist","Lab Technician","Security","Cleaner","Admin"]
        shifts=["Morning","Evening","Night","Rotating"]
        fc=card_frame(self,"➕ Add Staff"); fc.pack(fill="x",pady=(0,10))
        flds=[("Name",None),("Role",roles),("Phone",None),
              ("Salary Rs.",None),("Shift",shifts)]
        self._e={}
        for i,(lbl,opts) in enumerate(flds):
            r,c=divmod(i,3)
            tk.Label(fc,text=lbl,bg=C["card"],fg=C["fg2"],
                     font=("Consolas",9)).grid(row=r*2,column=c,sticky="w",padx=6,pady=(4,0))
            w=Combo(fc,values=opts,width=20) if opts else Ent(fc,width=22)
            w.grid(row=r*2+1,column=c,padx=6,pady=(2,6),ipady=5,sticky="ew")
            fc.columnconfigure(c,weight=1); self._e[lbl]=w

        bf=tk.Frame(fc,bg=C["card"]); bf.grid(row=6,column=0,columnspan=3,pady=6)
        Btn(bf,"💾 Add",    self._save,   "success").pack(side="left",padx=5)
        Btn(bf,"🗑️ Delete", self._delete, "danger").pack(side="left",padx=5)
        Btn(bf,"🔄 Refresh",self._load,   "purple").pack(side="left",padx=5)

        cols=["ID","Name","Role","Phone","Salary Rs.","Shift","Added"]
        self._tv=treeview(self,cols)
        self._tv.bind("<<TreeviewSelect>>",lambda _: self._sel())
        self._load()

    def _load(self):
        self._tv.delete(*self._tv.get_children())
        for i,r in enumerate(db.get_all_staff()):
            self._tv.insert("","end",values=(
                r["staff_id"],r["name"],r["role"],r["phone"],
                f"Rs.{r['salary']:.0f}",r["shift"],r["created_at"][:10],
            ),tags=("e" if i%2==0 else "o",))

    def _save(self):
        v={k:w.get() if isinstance(w,Combo) else w.val() for k,w in self._e.items()}
        if not v["Name"]: messagebox.showerror("Error","Name required!"); return
        db.add_staff(v["Name"],v["Role"],v["Phone"],
                     float(v["Salary Rs."] or 0),v["Shift"])
        messagebox.showinfo("✅","Staff added!")
        for w in self._e.values():
            if isinstance(w,Combo): w.set("")
            else: w.delete(0,"end")
        self._load()

    def _sel(self):
        sel=self._tv.selection()
        if sel: self._sid=self._tv.item(sel[0])["values"][0]

    def _delete(self):
        if not self._sid: messagebox.showwarning("⚠️","Select!"); return
        if messagebox.askyesno("Confirm","Delete staff?"):
            db.delete_staff(self._sid); self._sid=None; self._load()

# ══════════════════════════════════════════════════════════════
#  REPORTS
# ══════════════════════════════════════════════════════════════
class ReportsPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "📊  REPORTS & ANALYTICS")
        self._status=tk.StringVar(value="Ready to generate reports.")
        if not HAS_MATPLOTLIB:
            tk.Label(self,text="⚠️  matplotlib not installed.\nRun: pip install matplotlib",
                     bg=C["bg"],fg=C["a4"],font=("Consolas",13)).pack(pady=40)
            return
        self._build()

    def _build(self):
        intro=tk.Frame(self,bg=C["bg"]); intro.pack(fill="x",pady=(0,16))
        tk.Label(intro,text="Generate visual analytics charts for your hospital data.",
                 bg=C["bg"],fg=C["fg2"],font=("Consolas",10)).pack(anchor="w")

        grid=tk.Frame(self,bg=C["bg"]); grid.pack(fill="x",pady=(0,16))
        report_types=[
            ("📊 Full Dashboard Report",  "dashboard",  C["accent"],
             "8 charts: appointments, revenue, doctors, blood groups, patient demographics"),
            ("👥 Patient Analytics",      "patients",   C["a2"],
             "Monthly new patients + age group distribution"),
        ]
        for col,(title,key,color,desc) in enumerate(report_types):
            card=tk.Frame(grid,bg=C["card"],padx=16,pady=14,
                          highlightthickness=1,highlightbackground=color)
            card.grid(row=0,column=col,padx=10,sticky="nsew"); grid.columnconfigure(col,weight=1)
            tk.Label(card,text=title,bg=C["card"],fg=color,
                     font=("Consolas",12,"bold")).pack(anchor="w")
            tk.Label(card,text=desc,bg=C["card"],fg=C["fg2"],
                     font=("Consolas",9),wraplength=320,justify="left").pack(anchor="w",pady=6)
            bf=tk.Frame(card,bg=C["card"]); bf.pack(anchor="w",pady=(4,0))
            Btn(bf,"🔍 View",  lambda k=key: self._view(k), "primary").pack(side="left",padx=4)
            Btn(bf,"💾 Save",  lambda k=key: self._save(k), "success").pack(side="left",padx=4)

        tk.Label(self,textvariable=self._status,bg=C["bg"],fg=C["fg2"],
                 font=("Consolas",9)).pack(anchor="w",pady=(8,0))

    def _generate(self,key):
        self._status.set("⏳ Generating report…")
        self.update()
        tmp=os.path.join(tempfile.gettempdir(),f"medicore_{key}.png")
        if key=="dashboard":   rp.generate_dashboard_report(tmp)
        elif key=="patients":  rp.generate_patient_report(tmp)
        self._status.set(f"✅ Report generated: {tmp}")
        return tmp

    def _view(self,key):
        try:
            path=self._generate(key)
            self._show_image(path)
        except Exception as ex:
            messagebox.showerror("Error",str(ex))
            self._status.set(f"❌ Error: {ex}")

    def _save(self,key):
        path=filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG Image","*.png"),("All Files","*.*")],
            initialfile=f"medicore_{key}_report.png",
        )
        if not path: return
        try:
            self._generate(key)
            import shutil
            shutil.copy(os.path.join(tempfile.gettempdir(),f"medicore_{key}.png"), path)
            messagebox.showinfo("✅",f"Report saved:\n{path}")
        except Exception as ex:
            messagebox.showerror("Error",str(ex))

    def _show_image(self,path):
        try:
            from PIL import Image, ImageTk
            win=tk.Toplevel(); win.title("📊 Analytics Report")
            win.configure(bg=C["bg"])
            img=Image.open(path)
            w,h=img.size
            scale=min(1200/w,800/h,1)
            img=img.resize((int(w*scale),int(h*scale)),Image.LANCZOS)
            photo=ImageTk.PhotoImage(img)
            lbl=tk.Label(win,image=photo,bg=C["bg"]); lbl.image=photo; lbl.pack(padx=10,pady=10)
        except ImportError:
            # Fallback: open with default viewer
            import subprocess,platform
            if platform.system()=="Windows":   os.startfile(path)
            elif platform.system()=="Darwin":  subprocess.call(["open",path])
            else:                              subprocess.call(["xdg-open",path])

# ══════════════════════════════════════════════════════════════
#  USERS (admin only)
# ══════════════════════════════════════════════════════════════
class UsersPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "👤  USER MANAGEMENT")
        self._sid=None
        fc=card_frame(self,"➕ Add New User"); fc.pack(fill="x",pady=(0,10))
        roles=["admin","doctor","receptionist"]
        flds=[("Username",None),("Password",None),("Role",roles),
              ("Full Name",None),("Email",None)]
        self._e={}
        for i,(lbl,opts) in enumerate(flds):
            r,c=divmod(i,3)
            tk.Label(fc,text=lbl,bg=C["card"],fg=C["fg2"],
                     font=("Consolas",9)).grid(row=r*2,column=c,sticky="w",padx=6,pady=(4,0))
            if opts:
                w=Combo(fc,values=opts,width=22)
            elif lbl=="Password":
                w=Ent(fc,width=24,show="*")
            else:
                w=Ent(fc,width=24)
            w.grid(row=r*2+1,column=c,padx=6,pady=(2,6),ipady=5,sticky="ew")
            fc.columnconfigure(c,weight=1); self._e[lbl]=w

        bf=tk.Frame(fc,bg=C["card"]); bf.grid(row=6,column=0,columnspan=3,pady=6)
        Btn(bf,"💾 Add User",self._add,"success").pack(side="left",padx=5)
        Btn(bf,"🗑️ Delete",  self._del,"danger").pack(side="left",padx=5)
        Btn(bf,"🔄 Refresh", self._load,"purple").pack(side="left",padx=5)

        cols=["ID","Username","Role","Full Name","Email","Active","Created"]
        self._tv=treeview(self,cols)
        self._tv.bind("<<TreeviewSelect>>",lambda _: self._sel())
        self._load()

        tk.Label(self,text="ℹ️  Passwords are stored as SHA-256 hashes.",
                 bg=C["bg"],fg=C["fg2"],font=("Consolas",9)).pack(anchor="w",pady=6)

    def _load(self):
        self._tv.delete(*self._tv.get_children())
        for i,r in enumerate(auth.get_all_users()):
            self._tv.insert("","end",values=(
                r["user_id"],r["username"],r["role"],r["full_name"],
                r["email"],"Yes" if r["active"] else "No",r["created_at"][:10],
            ),tags=("e" if i%2==0 else "o",))

    def _add(self):
        u=self._e["Username"].val(); p=self._e["Password"].val()
        r=self._e["Role"].get(); fn=self._e["Full Name"].val()
        em=self._e["Email"].val()
        if not (u and p and r): messagebox.showerror("Error","Username,Password,Role required!"); return
        try:
            auth.add_user(u,p,r,fn,em)
            messagebox.showinfo("✅","User added!")
            for w in self._e.values():
                if isinstance(w,Combo): w.set("")
                else: w.delete(0,"end")
            self._load()
        except Exception as ex:
            messagebox.showerror("Error",str(ex))

    def _sel(self):
        sel=self._tv.selection()
        if sel: self._sid=self._tv.item(sel[0])["values"][0]

    def _del(self):
        if not self._sid: messagebox.showwarning("⚠️","Select user!"); return
        if self._sid==self.user["user_id"]:
            messagebox.showerror("Error","Cannot delete yourself!"); return
        if messagebox.askyesno("Confirm","Delete user?"):
            auth.delete_user(self._sid); self._sid=None; self._load()

# ══════════════════════════════════════════════════════════════
#  SETTINGS (Email config)
# ══════════════════════════════════════════════════════════════
class SettingsPage(BasePage):
    def __init__(self, master, user):
        super().__init__(master, user, "⚙️  SETTINGS")
        self._build()

    def _build(self):
        # Email settings
        ec=card_frame(self,"📧 Email / SMTP Configuration"); ec.pack(fill="x",pady=(0,14))
        cfg=em.get_email_settings()
        flds=[("SMTP Host",cfg.get("smtp_host","smtp.gmail.com")),
              ("SMTP Port",cfg.get("smtp_port","587")),
              ("Sender Email",cfg.get("sender_email","")),
              ("App Password",cfg.get("sender_password","")),]
        self._ee={}
        for i,(lbl,val) in enumerate(flds):
            r,c=divmod(i,2)
            tk.Label(ec,text=lbl,bg=C["card"],fg=C["fg2"],
                     font=("Consolas",9)).grid(row=r*2,column=c,sticky="w",padx=8,pady=(6,0))
            w=Ent(ec,width=35)
            if lbl=="App Password": w.config(show="*")
            w.insert(0,str(val))
            w.config(fg=C["fg"])
            w.grid(row=r*2+1,column=c,padx=8,pady=(2,8),ipady=6,sticky="ew")
            ec.columnconfigure(c,weight=1); self._ee[lbl]=w

        self._en_var=tk.IntVar(value=int(cfg.get("enabled",0)))
        tk.Checkbutton(ec,text="Enable Email Notifications",variable=self._en_var,
                       bg=C["card"],fg=C["a3"],activebackground=C["card"],
                       selectcolor=C["bg"],font=("Consolas",10)
                       ).grid(row=8,column=0,sticky="w",padx=8,pady=4)

        bf=tk.Frame(ec,bg=C["card"]); bf.grid(row=8,column=1,pady=6,sticky="e")
        Btn(bf,"💾 Save Settings",self._save_email,"success").pack(side="left",padx=5)
        Btn(bf,"🧪 Test Email",   self._test_email,"primary").pack(side="left",padx=5)

        # Hint
        hint="""Gmail App Password Setup:
  1. Go to Google Account → Security → 2-Step Verification (enable it)
  2. Go to App Passwords → Generate a new app password
  3. Use that 16-char password here (not your Gmail password)"""
        tk.Label(self,text=hint,bg=C["bg"],fg=C["fg2"],
                 font=("Consolas",9),justify="left").pack(anchor="w",pady=(4,0))

    def _save_email(self):
        host=self._ee["SMTP Host"].get()
        port=self._ee["SMTP Port"].get()
        sender=self._ee["Sender Email"].get()
        pwd=self._ee["App Password"].get()
        em.save_email_settings(host,port,sender,pwd,self._en_var.get())
        messagebox.showinfo("✅","Email settings saved!")

    def _test_email(self):
        self._save_email()
        cfg=em.get_email_settings()
        if not cfg.get("sender_email"):
            messagebox.showwarning("⚠️","Enter sender email first!"); return
        ok,msg=em._send(cfg["sender_email"],"🏥 MediCore — Test Email",
                        em._html_wrapper("<h3 style='color:#00FF9F;'>Test Successful ✅</h3>"
                                         "<p>Your email configuration is working correctly!</p>"))
        (messagebox.showinfo if ok else messagebox.showerror)("Test Result",msg)

# ══════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    lw = LoginWindow()
    lw.mainloop()
    if lw.user:
        HospitalApp(lw.user).mainloop()
